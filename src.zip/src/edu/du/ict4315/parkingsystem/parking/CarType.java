/////////////
//This is the CarType enumerated class
//File: CarType.java
//Author: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.parking;

public enum CarType {
	COMPACT, SUV;
}
