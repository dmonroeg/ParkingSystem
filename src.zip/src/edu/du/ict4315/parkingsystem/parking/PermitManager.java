/////////////
//This is the PermitManager class
//File: PermitManager.java
//Author: M. I. Schwartz
//Edited by: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.parking;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class PermitManager {
	private List<ParkingPermit> permits = new ArrayList<ParkingPermit>();

	private static int idCounter = 9000;

	public static String getPermitId() {
		idCounter += 1;
		return String.format("P%04d", idCounter);
	}

	public ParkingPermit register(Car car) {
		// TODO: Get an id better
		String carPermit = getPermitId();
		/*
		 * set expiration for one year from issuance
		 */
		LocalDateTime permitExpiration = LocalDateTime.now().plusYears(1);

		ParkingPermit permit = new ParkingPermit(carPermit, car, permitExpiration);
		permits.add(permit);
		return permit;
	}

	public ParkingPermit findPermit(String carPermit) {
		for (ParkingPermit p : permits) {
			if (p.getId().equals(carPermit)) {
				return p;
			}
		}
		return null;

	}
}
