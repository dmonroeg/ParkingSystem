/////////////
//This is the Car class
//File: Car.java
//Author: M. I. Schwartz
//Edited by: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.parking;

import java.util.Objects;

public class Car {
	private CarType type;
	private String licensePlate = "";
	private Customer owner;

	public Car() {
		type = CarType.COMPACT;
		owner = new Customer();
	}

	public Car(CarType type, String licensePlate, Customer owner) {
		this.type = type;
		this.licensePlate = licensePlate;
		this.owner = owner;
	}

	public CarType getType() {
		return type;
	}

	public void setType(CarType type) {
		this.type = type;
	}

	public String getLicensePlate() {
		return licensePlate;
	}

	public void setLicensePlate(String licensePlate) {
		this.licensePlate = licensePlate;
	}

	public Customer getOwner() {
		try {
			return owner;
		} catch (NullPointerException e) {
			System.out.println("null value found");
		}
		return owner;
	}

	public void setOwner(Customer owner) {
		this.owner = owner;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Car ");
		sb.append("[Type: ");
		sb.append(type);
		sb.append(" ");
		sb.append("|| License: ");
		sb.append(licensePlate);
		sb.append(" ");
		sb.append("|| Owner: ");
		sb.append(owner.getCustomerName());
		sb.append("]");

		return sb.toString();
	}

	@Override
	public boolean equals(Object o) {
		if (o == this) {
			return true;
		}
		if (!(o instanceof Car)) {
			return false;
		}
		Car c = (Car) o;
		// Car equality: Type, license plate
		return (c.getLicensePlate().contentEquals(licensePlate) && c.getType() == getType());

	}

	@Override
	public int hashCode() {
		return Objects.hash(getLicensePlate(), getType());
	}
}
