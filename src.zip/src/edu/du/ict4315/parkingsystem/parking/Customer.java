/////////////
//This is the Customer class
//File: Customer.java
//Author: M. I. Schwartz
//Edited by: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.parking;

//import java.time.LocalDate;
import java.util.Objects;

import edu.du.ict4315.parkingsystem.support.IdMaker;
import edu.du.ict4315.parkingsystem.support.User;

public class Customer {
	private String customerId;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private Address address;
	private User userInfo = null;

	public String getCustomerName() {
		return firstName + " " + lastName;
	}

	public static class Builder {
		/*
		 * required params
		 */
		private String firstName;
		private String lastName;
		/*
		 * optional params
		 */
		private String customerId;
		private String phoneNumber;
		private Address address;

		public Builder(String firstName, String lastName) {
			this.firstName = firstName;
			this.lastName = lastName;
		}

		public Builder withCustomerId(String customerId) {
			this.customerId = customerId;
			return this;
		}

		public Builder withPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;

			return this;
		}

		public Builder withAddress(Address address) {
			this.address = new Address.Builder().build();

			return this;
		}

		public Customer build() {
			return new Customer(this);

		}

	}

	public Customer() {
		customerId = IdMaker.makeId(this);
		firstName = "";
		lastName = "";
		phoneNumber = "";
		address = new Address.Builder().build();
	}

	private Customer(Builder builder) {
		customerId = builder.customerId;
		firstName = builder.firstName;
		lastName = builder.lastName;
		phoneNumber = builder.phoneNumber;
		address = builder.address;
	}

	public String getCustomerId() {
		return customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public Address getAddress() {
		return address;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void storeUserInfo(String passwd) {
		userInfo = User.authorizeUser(customerId, passwd);
	}

	public User getUserInfo() {
		return userInfo;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Customer ");
		sb.append(customerId);
		sb.append("\n");
		sb.append("Name: ");
		sb.append(lastName);
		sb.append(", ");
		sb.append(firstName);
		sb.append("\n");
		sb.append("Address: ");
		sb.append(address);
		sb.append("\n");
		sb.append("Phone Number: ");
		sb.append(phoneNumber);
		return sb.toString();
	}

	@Override
	public int hashCode() {
		return Objects.hash(address, customerId, firstName, lastName, phoneNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return Objects.equals(address, other.address) && Objects.equals(customerId, other.customerId)
				&& Objects.equals(firstName, other.firstName) && Objects.equals(lastName, other.lastName)
				&& Objects.equals(phoneNumber, other.phoneNumber);
	}

}