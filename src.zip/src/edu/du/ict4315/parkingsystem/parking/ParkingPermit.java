/////////////
//This is the ParkingPermit class
//File: ParkingPermit.java
//Author: M. I. Schwartz
//Edited by: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.parking;

import java.time.LocalDateTime;
import java.util.Objects;

public class ParkingPermit {
	public String carPermit;
	private Car car;
	private LocalDateTime expiration;

	public ParkingPermit(String carPermit, Car car, LocalDateTime expiration) {
		this.carPermit = PermitManager.getPermitId();
		this.car = car;
		this.expiration = expiration;
	}

	public String getId() {
		return carPermit;
	}

	public Car getCar() {
		return car;
	}

	public boolean isExpired() {
		LocalDateTime now = LocalDateTime.now();
		return expiration.isBefore(now);
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Permit ID: ");
		sb.append(carPermit);
		sb.append("\nPermit Expiration: ");
		sb.append(expiration.toLocalDate().toString());
		if (isExpired()) {
			sb.append(" (expired)");
		}
		sb.append("\nCar: ");
		sb.append(car.getType());
		sb.append("\nLicense Plate: ");
		if (car.getLicensePlate() != null && !car.getLicensePlate().isEmpty()) {
			sb.append(car.getLicensePlate());
		}
		return sb.toString();
	}

	// Since ParkingPermits are likely to be in collections, we must add equals and
	// hashCode
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (!(o instanceof ParkingPermit)) {
			return false;
		}
		ParkingPermit p = (ParkingPermit) o;
		if (p.carPermit != null && p.carPermit.equals(carPermit) && p.car != null && p.car.equals(car))
			return true;
		return false;
	}

	@Override
	public int hashCode() {
		return Objects.hash(carPermit, car);
	}
}
