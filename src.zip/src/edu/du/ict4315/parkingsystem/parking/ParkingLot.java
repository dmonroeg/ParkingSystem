/////////////
//This is the ParkingLot class
//File: ParkingLot.java
//Author: M. I. Schwartz
//Edited by: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.parking;

import java.time.Duration;
import java.time.LocalDateTime;

import edu.du.ict4315.currency.Money;
import edu.du.ict4315.parkingsystem.charges.factory.FactoryParkingChargeCalculator;
import edu.du.ict4315.parkingsystem.charges.factory.FactoryWeekendCharge;

public class ParkingLot {
	private String id;
	private String name;
	private Address address;
	private Money baseRate = Money.of(5.00);
	private static FactoryParkingChargeCalculator parkingChargeCalculatorFactory;

	public ParkingLot(String id, String name, Address address, Money baseRate) {
		this(id, name, address, baseRate, (FactoryParkingChargeCalculator) new FactoryWeekendCharge());
	}

	public ParkingLot(String id, String name, Address address, Money baseRate, FactoryParkingChargeCalculator factory) {
		this.id = id;
		this.name = name;
		this.address = address;
		this.baseRate = baseRate;
		this.parkingChargeCalculatorFactory = factory;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public Address getAddress() {
		return address;
	}

	public Money getBaseRate() {
		return baseRate;
	}

	public Money getParkingCharges(ParkingPermit p, LocalDateTime in, Duration duration) {
		Money money = parkingChargeCalculatorFactory.getCalculator().getParkingCharge(this, p, in);
		return money;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Parking Lot: ");
		sb.append(id);
		sb.append("\n");
		sb.append(name);
		sb.append("\n");
		sb.append(address);

		return sb.toString();
	}

	// permit-required-on-enter lot
	public void enterLot(LocalDateTime in, String carPermit) {

	}

	// entry-exit-scan lot
	public void exitLot(LocalDateTime in, LocalDateTime out, String permitId) {

	}

}