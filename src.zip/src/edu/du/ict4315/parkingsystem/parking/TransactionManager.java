/////////////
//This is the TransactionManager class
//File: TransactionManager.java
//Author: M. I. Schwartz
//Edited by: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.parking;

import java.util.logging.Logger;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import edu.du.ict4315.currency.Money;

public class TransactionManager {

	private static final Logger logger = Logger.getLogger(TransactionManager.class.getName());

	private List<ParkingTransaction> transactions = new ArrayList<ParkingTransaction>();
	private ParkingOffice office;

	public TransactionManager(ParkingOffice office) {
		this.office = office;
	}

	public ParkingTransaction park(ParkingPermit p, ParkingLot l, LocalDateTime in, LocalDateTime out) {
		if (l != null && p != null && l != null) {
			Duration duration = Duration.between(in, out);
			Money money = l.getParkingCharges(p, in, duration);
			ParkingTransaction transaction = new ParkingTransaction.Builder(p, money).withDate(in).withParkingLot(l)
					.build();
			transactions.add(transaction);
			return transaction;
		} else {

		}
		return null;
	}

	public Money getParkingCharges(Customer c) {
		List<ParkingTransaction> customerTransactions;
		// First, let's get a list of the transactions for the customer.
		customerTransactions = transactions.stream()
				.filter(transaction -> transaction.getPermit().getCar().getOwner().equals(c))
				.collect(Collectors.toList());

		// Now lets add up all the charged amounts
		Money result = customerTransactions.stream().map(transaction -> transaction.getChargedAmount())
				.reduce(Money.of(0.0), (a, b) -> Money.add(a, b));

		return result;
	}

	public Money getParkingCharges(ParkingPermit p) {
		return transactions.stream().filter(transaction -> transaction.getPermit().equals(p))
				.map(transaction -> transaction.getChargedAmount()).reduce(Money.of(0.0), (a, b) -> Money.add(a, b));
	}

}
