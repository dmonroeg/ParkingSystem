/////////////
//This is the ParkingTransaction class
//File: ParkingTransaction.java
//Author: M. I. Schwartz
//Edited by: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.parking;

import java.time.Instant;
import java.time.LocalDateTime;

import edu.du.ict4315.currency.Money;

public class ParkingTransaction {
	private Instant transactionDate;
	private LocalDateTime date;
	private ParkingPermit carPermit;
	private ParkingLot parkingLot;
	private Money chargedAmount;

	public static class Builder {
		/*
		 * required params
		 */
		private final ParkingPermit carPermit;
		private final Money chargedAmount;
		/*
		 * optional params
		 */
		private Instant transactionDate;
		private ParkingLot parkingLot;
		private LocalDateTime date;

		public Builder(ParkingPermit carPermit, Money chargedAmount) {
			this.carPermit = carPermit;
			this.chargedAmount = chargedAmount;
		}

		public ParkingTransaction.Builder withTransactionDate(Instant transactionDate) {
			this.transactionDate = transactionDate;
			return this;
		}

		public ParkingTransaction.Builder withParkingLot(ParkingLot parkingLot) {
			this.parkingLot = parkingLot;
			return this;
		}

		public ParkingTransaction.Builder withDate(LocalDateTime date) {
			this.date = date;
			return this;
		}

		public ParkingTransaction build() {
			return new ParkingTransaction(this);
		}
	}

	private ParkingTransaction(Builder builder) {
		transactionDate = builder.transactionDate;
		date = builder.date;
		carPermit = builder.carPermit;
		parkingLot = builder.parkingLot;
		chargedAmount = builder.chargedAmount;
	}

	public Money getChargedAmount() {
		return chargedAmount;
	}

	public ParkingPermit getPermit() {
		return carPermit;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public ParkingLot getParkingLot() {
		return parkingLot;
	}

	public Instant getTransactionDate() {
		return transactionDate;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();

		sb.append("Transaction:");
		sb.append("\nLogged: ");
		sb.append(transactionDate);
		sb.append("\nParked: ");
		sb.append(date);
		sb.append("\nPermit: ");
		sb.append(carPermit.getId());
		sb.append("\nLot: ");
		sb.append(parkingLot.getName());
		sb.append("\nAmount Charged: ");
		sb.append(chargedAmount);

		return sb.toString();
	}
}