//////////////////////////
// This class represents a parking office client for "smoke test" use.
// The client is in the same JVM as the Parking Office
// File: ParkingOfficeClient.java
// Author: M. I. Schwartz
//////////////////////////
package edu.du.ict4315.parkingsystem.clients;

import edu.du.ict4315.parkingsystem.parking.Address;
import edu.du.ict4315.parkingsystem.parking.Car;
import edu.du.ict4315.parkingsystem.parking.CarType;
import edu.du.ict4315.parkingsystem.parking.Customer;
import edu.du.ict4315.parkingsystem.parking.ParkingLot;
import edu.du.ict4315.parkingsystem.parking.ParkingOffice;

public class ParkingOfficeClient {
	public static void main(String[] args) {
		ParkingOffice office = new ParkingOffice();
		office.setParkingOfficeName("DU Parking Office");
		office.setParkingOfficeAddress(new Address.Builder().withStreetAddress1("2130 S. High St.").withCity("Denver")
				.withState("CO").withZip("80208").build());
		sampleTransactions(office);
		System.out.println(office);
	}

	// Ths sampleTransactions method can be augmented to include whatever tests you
	// like.
	public static void sampleTransactions(ParkingOffice office) {
		// Use case: Add a customer
		Customer customer = new Customer.Builder("Daphne", "Monroe").withCustomerId("DM5678")
				.withPhoneNumber("7196856408").withAddress(new Address.Builder().withStreetAddress1("1931 S 80th Dr")
						.withCity("Phoenix").withState("AZ").withZip("85043").build())
				.build();

		// Use case: Register Customer
		String customerId = office.register(customer);
		System.out.println("Registered Daphne Monroe: " + customerId);

		// Use case: Give customer a car
		Car car1 = new Car(CarType.COMPACT, "987GHF", customer);
		Car car2 = new Car(CarType.SUV, "BNA8843", customer);

		// Use Case: Register Car
		String permit1 = office.register(car1);
		String permit2 = office.register(car2);

		System.out.println("Permit: " + office.getParkingPermit(permit1));
		System.out.println("Permit: " + office.getParkingPermit(permit2));

		// Park in Lot W
		ParkingLot lot = office.getParkingLot("Science East");
		System.out.println("Lot: " + lot);
	}
}