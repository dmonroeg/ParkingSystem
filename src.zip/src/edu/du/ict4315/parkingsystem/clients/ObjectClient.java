/////////////////////////////
// This is the ObjectClient class
// File: ObjectClient.java
// Author: M. I. Schwartz
// Edited: Daphne M. Goujon
// This file has been edited from the original 
// ServerClient class to ObjectClient as 
// outlined in both the assignment amplification
// and the in-class card exercise
/////////////////////////////
package edu.du.ict4315.parkingsystem.clients;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import edu.du.ict4315.parkingsystem.command.GsonParkingRequest;
import edu.du.ict4315.parkingsystem.command.GsonParkingResponse;
import edu.du.ict4315.parkingsystem.command.ParkingRequest;
import edu.du.ict4315.parkingsystem.command.ParkingResponse;

public class ObjectClient {

	// The displayCommands will be sorted by key order in the GUI, so alphabetizing
	// is good.
	// First 2 characters are stripped from description to button label
	public static final String[][] COMMANDS = new String[][] {
			{ "a. Register Customer", "CUSTOMER", "FirstName", "LastName" },
			{ "b. Register Vehicle", "CAR", "License", "Customer" },
			{ "c. Parking", "PARK", "Lot", "Permit Id", "Time" }, { "d. Get Charges", "CHARGES", "Customer", "Car" },
			{ "e. Stop the server and print statistics", "STOP" } };

	// This must match the server's selected port and host
	private static final int PORT = 7778;
	private static final String SERVER = "localhost";

	private ObjectClient() {
	}

	public static ParkingRequest parseCommand(String[] request) {
		if (request.length == 0) {
			System.err.println("No command present");
			return null;
		}

		String commandName = null;
		String[] parameters = null;
		List<String> fieldNames = new ArrayList<String>();
		for (String[] command : COMMANDS) {
			if (command[1].equalsIgnoreCase(request[0].trim())) {
				commandName = command[1];
				parameters = new String[command.length - 2];
				for (int j = 1; j < request.length; j++) {
					String[] parts = request[j].split("=");
					if (parts.length == 2) {
						for (int k = 0; k < parameters.length; k++) {
							if (command[k + 2].equalsIgnoreCase(parts[0].trim())) {
								parameters[k] = parts[1].trim().toLowerCase();
							}
						}
					} else {
						System.err.println("Bad parameter " + request[j]);
					}
				}
				return new ParkingRequest(commandName, parameters, fieldNames);
			}
		}
		System.err.println("Command " + request[0] + " not recognized");
		return null;
	}

	public static ParkingResponse runCommand(ParkingRequest parkingRequest) throws IOException, ClassNotFoundException {

		InetAddress host = InetAddress.getByName(SERVER);
		ParkingResponse response = null;
		try (Socket link = new Socket(host, PORT);
				ObjectOutputStream osw = new ObjectOutputStream(link.getOutputStream());
				ObjectInputStream isw = new ObjectInputStream(link.getInputStream());) {
			System.out.println("You are now connected to: " + host.getHostAddress());

			Object o = new GsonParkingRequest(parkingRequest).getJsonObject();
			System.out.println(" Sending a " + o.getClass().getName());
			osw.writeObject(o);

			Object obj = isw.readObject();
			if (obj instanceof String) {
				response = GsonParkingResponse.fromJsonString(obj.toString());
				System.out.println(" Receiving a " + response);
			} else if (obj instanceof ParkingResponse) {
				response = (ParkingResponse) obj;
				System.out.println(response);
			} else {
				// remaining null
				// string already printed
			}
		}
		return response;
	}

	public static Map<String, ParkingRequest> displayCommands() {
		Map<String, ParkingRequest> commands = new TreeMap<>();
		for (String[] description : COMMANDS) {
			commands.put(description[0], new ParkingRequest(description[0].substring(2), new String[0],
					Arrays.asList(description).subList(2, description.length)));

		}
		return commands;
	}

	public static Map<String, ParkingRequest> commands() {
		Map<String, ParkingRequest> commands = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
		for (String[] description : COMMANDS) {
			commands.put(description[1], new ParkingRequest(description[0].substring(2), new String[0],
					Arrays.asList(description).subList(2, description.length)));
		}
		return commands;
	}

	/**
	 * Run this as: $ java ict4315.client.Client COMMAND label1=value1 label2=value2
	 * ... Use LIST to get the list of commands and their labels.
	 */
	public static void main(String[] args) throws IOException, ClassNotFoundException {

		if (args.length == 0 || args[0].equals("LIST")) {
			System.out.println("Here are the commands we know about.");
			System.out.println("Usage: $ java edu.du.ict4315.parkingsystem.clients.ObjectClient COMMAND");
			System.out.println();
			for (String[] description : COMMANDS) {
				System.out.format("%s: %s ", description[0], description[1]);
				for (int i = 2; i < description.length; ++i) {
					System.out.format("%s=value ", description[i].replaceAll(" ", "").toLowerCase());
				}
				System.out.println();
			}
			return;
		}

		ParkingRequest command = commands().get(args[0]);
		if (command == null) {
			System.out.println("Unrecognised command: " + args[0]);
			System.out.print("Known commands: ");
			String comma = "";
			for (String[] description : COMMANDS) {
				System.out.print(comma + description[1]);
				comma = ", ";
			}
			System.out.println();
			return;
		}

		Map<String, String> values = new LinkedHashMap<>();
		for (String label : command.fieldNames()) {
			for (int i = 0; i < args.length; ++i) {
				if (args[i].startsWith(label.replaceAll(" ", "").toLowerCase())) {
					values.put(label, args[i].replaceAll(".*=", ""));
					break;
				}
			}
		}

		ParkingRequest request = parseCommand(args);
		System.out.println("Request:\n  " + request);
		if (request != null) {
			ParkingResponse response = ObjectClient.runCommand(request);
			System.out.println(response);
		}
	}
}