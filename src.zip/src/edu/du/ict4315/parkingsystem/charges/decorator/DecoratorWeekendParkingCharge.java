/////////////
//This is the WeekendParkingChargeTest decorator class
//File: WeekendParkingChargeTest.java
//Author: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.charges.decorator;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import edu.du.ict4315.currency.Money;
import edu.du.ict4315.parkingsystem.parking.ParkingLot;
import edu.du.ict4315.parkingsystem.parking.ParkingPermit;

public class DecoratorWeekendParkingCharge extends ParkingChargeCalculatorDecorator {

	private final String description;
	private List<DayOfWeek> weekendDays;

	public DecoratorWeekendParkingCharge(ParkingChargeCalculator calculator) {
		super(calculator);
		weekendDays = List.of(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY);
		description = "Weekend Discount: " + weekendDays.toString();
	}

	public DecoratorWeekendParkingCharge(ParkingChargeCalculator calculator, DayOfWeek[] weekendDays) {
		super(calculator);
		this.weekendDays = Arrays.asList(weekendDays);
		description = "Weekend Discount: " + this.weekendDays.toString();
	}

	@Override
	public List<String> getDescription() {
		List<String> list = getChargeCalculator().getDescription();
		list.add(description);
		return list;
	}

	private boolean isWeekendDay(LocalDateTime d) {
		return weekendDays.contains(d.getDayOfWeek());
	}

	@Override
	public Money getParkingCharge(ParkingLot parkingLot, ParkingPermit permit, LocalDateTime in, LocalDateTime out) {
		Money result = getChargeCalculator().getParkingCharge(parkingLot, permit, in, out);
		if (permit != null && permit.getCar() != null && isWeekendDay(in)) {
			if (isWeekendDay(in) == true) {
				result = Money.times(result, .5);
			}
		}
		return result;
	}
}
