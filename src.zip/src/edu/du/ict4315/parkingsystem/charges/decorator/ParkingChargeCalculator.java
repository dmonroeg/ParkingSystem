/////////////
//This is the ParkingChargeCalculator class
//File: ParkingChargeCalculator.java
//Author: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.charges.decorator;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import edu.du.ict4315.currency.Money;
import edu.du.ict4315.parkingsystem.parking.ParkingLot;
import edu.du.ict4315.parkingsystem.parking.ParkingPermit;

public abstract class ParkingChargeCalculator {

	private final String description = "Parking Charge Description: ";

	public Money getParkingCharge(ParkingLot parkingLot, ParkingPermit parkingPermit, LocalDateTime in) {
		// entry scan only lots can use default
		return getParkingCharge(parkingLot, parkingPermit, in, in);
	}

	public abstract Money getParkingCharge(ParkingLot parkingLot, ParkingPermit permit, LocalDateTime in,
			LocalDateTime out);

	protected List<String> getDescription() {
		List<String> list = new ArrayList<>();
		list.add(description);
		return list;
	}

	@Override
	public String toString() {
		return String.join("-", getDescription());
	}
}
