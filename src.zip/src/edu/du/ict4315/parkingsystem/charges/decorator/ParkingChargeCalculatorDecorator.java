/////////////
//This is the ParkingChargeCalculatorDecorator decorator class
//File: ParkingChargeCalculatorDecorator.java
//Author: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.charges.decorator;

import java.util.List;

public abstract class ParkingChargeCalculatorDecorator extends ParkingChargeCalculator {
	private final ParkingChargeCalculator chargeCalculator;

	public ParkingChargeCalculatorDecorator(ParkingChargeCalculator calculator) {
		chargeCalculator = calculator;
	}

	@Override
	public List<String> getDescription() {
		return chargeCalculator.getDescription();
	}

	public final ParkingChargeCalculator getChargeCalculator() {
		return chargeCalculator;
	}

}
