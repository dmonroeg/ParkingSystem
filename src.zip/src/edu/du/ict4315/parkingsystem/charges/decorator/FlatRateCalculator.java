/////////////
//This is the FlatRateCalculator class
//File: FlatRateCalculator.java
//Author: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.charges.decorator;

import java.time.LocalDateTime;

import edu.du.ict4315.currency.Money;
import edu.du.ict4315.parkingsystem.parking.ParkingLot;
import edu.du.ict4315.parkingsystem.parking.ParkingPermit;

public class FlatRateCalculator extends ParkingChargeCalculator {

	private final String description = "Flat Rate";

	@Override
	public Money getParkingCharge(ParkingLot parkingLot, ParkingPermit permit, LocalDateTime in, LocalDateTime out) {
		Money baseRate = parkingLot.getBaseRate();
		return baseRate;
	}

}