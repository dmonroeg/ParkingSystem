/////////////
//This is the CompactParkingCharge decorator class
//File: CompactParkingCharge.java
//Author: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.charges.decorator;

import java.time.LocalDateTime;
import java.util.List;

import edu.du.ict4315.currency.Money;
import edu.du.ict4315.parkingsystem.parking.CarType;
import edu.du.ict4315.parkingsystem.parking.ParkingLot;
import edu.du.ict4315.parkingsystem.parking.ParkingPermit;

public class DecoratorCompactParkingCharge extends ParkingChargeCalculatorDecorator {

	private final String description;

	public DecoratorCompactParkingCharge(ParkingChargeCalculator calculator) {
		super(calculator);
		description = "Compact Car 20% Discount";
	}

	@Override
	public List<String> getDescription() {
		List<String> list = getChargeCalculator().getDescription();
		list.add(description);
		return list;
	}

	@Override
	public Money getParkingCharge(ParkingLot parkingLot, ParkingPermit permit, LocalDateTime in, LocalDateTime out) {
		Money result = getChargeCalculator().getParkingCharge(parkingLot, permit, in, out);
		if (permit != null && permit.getCar() != null) {
			if (permit.getCar().getType() == CarType.COMPACT) {
				result = Money.times(result, .8);
			}
		}
		return result;
	}

}
