package edu.du.ict4315.parkingsystem.charges.factory;

import edu.du.ict4315.parkingsystem.charges.decorator.ParkingChargeCalculator;

public interface FactoryParkingChargeCalculator {
	ParkingChargeCalculator getCalculator();

}
