package edu.du.ict4315.parkingsystem.charges.factory;

import edu.du.ict4315.parkingsystem.charges.decorator.DecoratorCompactParkingCharge;
import edu.du.ict4315.parkingsystem.charges.decorator.FlatRateCalculator;
import edu.du.ict4315.parkingsystem.charges.decorator.ParkingChargeCalculator;

public class FactoryCompactParkingCharge implements FactoryParkingChargeCalculator {

	@Override
	public ParkingChargeCalculator getCalculator() {
		return new DecoratorCompactParkingCharge(new FlatRateCalculator());
	}

}
