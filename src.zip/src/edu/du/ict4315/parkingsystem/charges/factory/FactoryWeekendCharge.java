package edu.du.ict4315.parkingsystem.charges.factory;

import java.time.DayOfWeek;

import edu.du.ict4315.parkingsystem.charges.decorator.DecoratorCompactParkingCharge;
import edu.du.ict4315.parkingsystem.charges.decorator.DecoratorWeekendParkingCharge;
import edu.du.ict4315.parkingsystem.charges.decorator.FlatRateCalculator;
import edu.du.ict4315.parkingsystem.charges.decorator.ParkingChargeCalculator;
import edu.du.ict4315.parkingsystem.charges.decorator.ParkingChargeCalculatorDecorator;

public class FactoryWeekendCharge implements FactoryParkingChargeCalculator {

	@Override
	public ParkingChargeCalculator getCalculator() {
		DayOfWeek[] days = { DayOfWeek.SATURDAY, DayOfWeek.SUNDAY };
		return new DecoratorWeekendParkingCharge(new DecoratorCompactParkingCharge(new FlatRateCalculator()), days);
	}
}
