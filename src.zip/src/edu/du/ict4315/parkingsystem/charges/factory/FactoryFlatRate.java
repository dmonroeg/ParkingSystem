package edu.du.ict4315.parkingsystem.charges.factory;

import edu.du.ict4315.parkingsystem.charges.decorator.FlatRateCalculator;
import edu.du.ict4315.parkingsystem.charges.decorator.ParkingChargeCalculator;

public class FactoryFlatRate implements FactoryParkingChargeCalculator {

	@Override
	public ParkingChargeCalculator getCalculator() {
		return new FlatRateCalculator();
	}

}
