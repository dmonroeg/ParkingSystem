/////////////
//This is the IdMaker class
//File: IdMaker.java
//Author: M. I. Schwartz
//Edited: Daphne M. Goujon
////////////
package edu.du.ict4315.parkingsystem.support;

import java.util.concurrent.atomic.AtomicInteger;

import edu.du.ict4315.parkingsystem.parking.Customer;

public class IdMaker {
	private static final AtomicInteger counter = new AtomicInteger(100);

	public static String makeId(Customer cust) {
		String name = cust.getCustomerName();
		String prefix = name.replaceAll("^\\s*([a-zA-Z]).*\\s+([a-zA-Z])\\S+$", "$1$2").toUpperCase();
		/*
		 * making the prefix the customer's intitals ^ - Start of string \s* - Matches
		 * optional whitespace(s) ([a-zA-Z]) - Matches the first letter of firstname and
		 * captures it in group1 .*\s+ - Here .* matches any text greedily and \s+
		 * ensures it matches the last whitespace just before last name ([a-zA-Z]) -
		 * This captures the first letter of lastname and captures it in group2 \S+$ -
		 * Matches remaining part of lastname and end of input
		 */

		return prefix + counter.incrementAndGet();
	}

}