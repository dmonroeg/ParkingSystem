/////////////
//This is the UserRole enumerated class
//File: UserRole.java
//Author: M. I. Schwartz
////////////
package edu.du.ict4315.parkingsystem.support;

public enum UserRole {
	ADMIN, CUSTOMER, MAINT, OTHER
}
