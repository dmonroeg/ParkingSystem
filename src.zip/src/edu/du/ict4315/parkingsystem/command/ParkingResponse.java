/////////////
//This is the ParkingResponse class
//File: ParkingResponse.java
//Author: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.command;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ParkingResponse implements Serializable {

	private static final long serialVersionUID = -140277994055337352L;
	private final int responseCode;
	private final String responseText;
	private List<String> messages;

	public ParkingResponse(int responseCode, String responseText) {
		this.responseCode = responseCode;
		this.responseText = responseText;
		this.messages = new ArrayList<>();
	}

	public void addMessage(String msg) {
		messages.add(msg);
	}

	public String[] getMessages() {
		return messages.toArray(new String[0]);
	}

	public int getResponseCode() {
		return responseCode;
	}

	public String getResponseText() {
		return responseText;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Response code: ");
		sb.append(responseCode);
		sb.append(": (");
		sb.append(responseText);
		sb.append(")");
		sb.append("::  ");
		sb.append(messages.toString());
		return sb.toString();
	}

	// parse string back into response
	// response code is 200, response text is Success, brackets surround array,
	// commas separate messages.
	public static ParkingResponse fromString(String responseText) {
		ParkingResponse response;
		try {
			String[] parts = responseText.split("::");
			String[] statusParts = parts[0].split(":");
			String code = statusParts[1].trim();
			String codeText = statusParts[2].replace('(', ' ').replace(')', ' ').trim();
			String[] messages = parts[1].replace('[', ' ').replace(']', ' ').trim().split(", ");

			response = new ParkingResponse(Integer.valueOf(code), codeText);
			for (String s : messages) {
				response.addMessage(s);
			}
		} catch (NullPointerException | NumberFormatException ex) {
			response = new ParkingResponse(500, "Error parsing |" + responseText + "|");
		}
		return response;
	}

}
