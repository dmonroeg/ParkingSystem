/////////////////////////////
// This is the GsonParkingResponse class
// File: GsonParkingResponse.java
// Author: M. I. Schwartz
// Edited: Daphne M. Goujon
// This file has been edited from the
// in-class CardExample project
/////////////////////////////
package edu.du.ict4315.parkingsystem.command;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GsonParkingResponse {
	private final ParkingResponse parkingResponse;
	private static final Gson gson = new GsonBuilder().create();

	public GsonParkingResponse(ParkingResponse response) {
		parkingResponse = response;
	}

	public ParkingResponse getJsonCommand() {
		return parkingResponse;
	}

	public static ParkingResponse fromJsonString(String json) {
		return gson.fromJson(json, ParkingResponse.class);
	}

	@Override
	public String toString() {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		return gson.toJson(parkingResponse);
	}

}
