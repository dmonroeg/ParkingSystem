/////////////
//This is the ParkingRequest class
//File: ParkingRequest.java
//Author: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.command;

import java.io.IOException;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import edu.du.ict4315.parkingsystem.clients.ObjectClient;

public class ParkingRequest implements Serializable {

	private static final long serialVersionUID = -3388404417724375131L;
	private final String commandName;
	private final String[] parameters;
	private final List<String> fieldNames;

	public ParkingRequest(String name, String[] params, List<String> fieldNames) {
		this.commandName = name;
		this.parameters = params;
		this.fieldNames = Collections.unmodifiableList(fieldNames);
	}

	public String getCommandName() {
		return commandName;
	}

	public String[] getParameters() {
		return parameters;
	}

	public List<String> fieldNames() {
		return fieldNames;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Command: ");
		sb.append(commandName);
		sb.append("::  ");
		sb.append(String.join(", ", parameters));
		return sb.toString();
	}

	public String executeObject(ParkingRequest command) {
		try {
			return ObjectClient.runCommand(command).toString();
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace(); // debugging help
			return e.getMessage();
		}
	}

}
