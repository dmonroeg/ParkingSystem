/////////////////////////////
// This is the GsonParkingRequest class
// File: GsonParkingRequest.java
// Author: M. I. Schwartz
// Edited: Daphne M. Goujon
// This file has been edited from the
// in-class CardExample project
/////////////////////////////
package edu.du.ict4315.parkingsystem.command;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GsonParkingRequest {

	private final ParkingRequest parkingRequest;
	private static final Gson gson = new GsonBuilder().create();

	public GsonParkingRequest(ParkingRequest request) {
		parkingRequest = request;
	}

	public String getJsonObject() {
		Gson gson = new GsonBuilder().create();
		return gson.toJson(parkingRequest);
	}

	public ParkingRequest getParkingRequest() {
		return parkingRequest;
	}

	public static ParkingRequest fromJsonString(String json) {
		return gson.fromJson(json, ParkingRequest.class);
	}

	@Override
	public String toString() {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		return gson.toJson(parkingRequest);
	}

}
