/////////////////////////////
// This is the ObjectWritingServer class
// File: ObjectWritingServer.java
// Author: M. I. Schwartz
// Edited: Daphne M. Goujon
// This file has been edited from the
// in-class CardExample project
/////////////////////////////
package edu.du.ict4315.parkingsystem.server;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.Duration;
import java.time.Instant;
import java.util.logging.Level;
import java.util.logging.Logger;

import edu.du.ict4315.parkingsystem.command.ParkingResponse;
import edu.du.ict4315.parkingsystem.parking.Address;
import edu.du.ict4315.parkingsystem.parking.ParkingOffice;

public class ObjectWritingServer {
	private ParkingService service;

	static {
		System.setProperty("java.util.logging.SimpleFormatter.format", "%1$tc %4$-7s (%2$s) %5$s %6$s%n");
	}

	private static final Logger logger = Logger.getLogger(ObjectWritingServer.class.getName());

	private final int PORT = 7778;

	public ObjectWritingServer(ParkingService service) {
		this.service = service;
	}

	private Duration cumulativeDuration = Duration.ZERO;
	private int countConnections = 0;
	private static volatile boolean doContinue = true;

	public void startServer() throws IOException {
		logger.info("Starting server: " + InetAddress.getLocalHost().getHostAddress());
		InetAddress.getLocalHost().getHostAddress();
		try (ServerSocket serverSocket = new ServerSocket(PORT)) {
			serverSocket.setReuseAddress(true);
			logger.info("	Using port " + PORT);
			while (doContinue) {
				Socket client = serverSocket.accept();
				Instant start = Instant.now();
				Runnable r = new HandleRemoteClient(client, service);
				Instant done = Instant.now();
				new Thread(r).start();
				cumulativeDuration = cumulativeDuration.plus(Duration.between(start, done));
				countConnections++;
			}
			System.out.println(getConnectionStatistics());
		}
	}

	private String getConnectionStatistics() {
		StringBuilder sb = new StringBuilder();
		sb.append("Handled " + countConnections + " connections in " + cumulativeDuration);
		if (countConnections > 0) {
			sb.append("    " + (cumulativeDuration.toNanos() / countConnections) + " ns. per connection");
		}
		return sb.toString();
	}

	protected void handleClient(Socket client) {
		try (ObjectOutputStream osw = new ObjectOutputStream(client.getOutputStream())) {
			ParkingResponse output;
			try {
				output = service.handleInputObject(client.getInputStream());
			} catch (Exception ex) {
				output = new ParkingResponse(401, "Exception");
				output.addMessage(ex.getMessage());
				ex.printStackTrace();
			}

			osw.writeObject(output);
		} catch (IOException e) {
			logger.log(Level.WARNING, "Failed to read from client.", e);
		} finally {
			try {
				client.close();
			} catch (IOException e) {
				logger.log(Level.WARNING, "Failed to close client socket.", e);
			}
		}
	}

	public static void stopServer() {
		doContinue = false;
		Thread.currentThread().interrupt();
	}

	/**
	 * Run this as: $ java edu.du.ict4315.parkingsystem.server.ObjectWritingServer
	 */
	public static void main(String[] args) throws Exception {
		ParkingOffice office = new ParkingOffice();
		office.setParkingOfficeName("DU Parking Office");
		office.setParkingOfficeAddress(new Address.Builder().withStreetAddress1("2130 S. High St.").withCity("Denver")
				.withState("CO").withZip("80208").build());
		ParkingService service = new ParkingService(office);

		new ObjectWritingServer(service).startServer();

	}
}
