/////////////
//This is the HandleRemoteClient class
//File: HandleRemoteClient.java
//Author: M. I. Schwartz
//Edited: Daphne M. Goujon
////////////
package edu.du.ict4315.parkingsystem.server;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

import edu.du.ict4315.parkingsystem.command.ParkingResponse;

public class HandleRemoteClient implements Runnable {
	private Socket client;
	private ParkingService service;

	public HandleRemoteClient(Socket s, ParkingService parkingService) {
		client = s;
		service = parkingService;
	}

	@Override
	public void run() {
		try (ObjectOutputStream osw = new ObjectOutputStream(client.getOutputStream())) {
			ParkingResponse output;
			output = service.handleInputObject(client.getInputStream());
			osw.writeObject(output);
		} catch (IOException e) {
			System.err.println("IOException: " + e.getLocalizedMessage());
		} catch (ClassNotFoundException e) {
			System.err.println("ClassNotFoundException: " + e.getLocalizedMessage());
		}

	}

}
