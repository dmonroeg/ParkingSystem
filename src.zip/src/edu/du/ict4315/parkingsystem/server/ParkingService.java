/////////////
//This is the ParkingService class
//File: ParkingService.java
//Author: M. I. Schwartz
//Edited: Daphne M. Goujon
////////////
package edu.du.ict4315.parkingsystem.server;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import edu.du.ict4315.parkingsystem.parking.Car;
import edu.du.ict4315.parkingsystem.parking.CarType;
import edu.du.ict4315.parkingsystem.parking.Customer;
import edu.du.ict4315.parkingsystem.parking.ParkingOffice;
import edu.du.ict4315.parkingsystem.parking.ParkingLot;
import edu.du.ict4315.parkingsystem.parking.ParkingPermit;
import edu.du.ict4315.parkingsystem.parking.ParkingTransaction;
import edu.du.ict4315.parkingsystem.command.GsonParkingRequest;
import edu.du.ict4315.parkingsystem.command.ParkingRequest;
import edu.du.ict4315.parkingsystem.command.ParkingResponse;

public class ParkingService {

	private static final Logger logger = Logger.getLogger(ParkingService.class.getName());
	protected final ParkingOffice parkingOffice;

	public ParkingService(ParkingOffice parkingOffice) {
		this.parkingOffice = parkingOffice;

	}

	// have a case statement select a handling strategy based on the received type.
	public ParkingResponse handleInputObject(InputStream in) throws IOException, ClassNotFoundException {
		ParkingResponse result;
		final String[] emptyParameters = {};
		BufferedInputStream bis = new BufferedInputStream(in);
		if (bis.markSupported()) {
			bis.mark(4);
		}
		ObjectInputStream ois = new ObjectInputStream(bis);
		Object obj = ois.readObject();
		logger.info("Object Type: " + obj.getClass().getName());
		/*
		 * There are 3 different implementations of the Object server, combining our 3
		 * approaches
		 */
		if (obj instanceof ParkingRequest) {
			ParkingRequest request = (ParkingRequest) obj;
			logger.info("Parking Request Recieved: " + request.toString());
			result = performCommand(request);
		} else if (obj instanceof String) {
			logger.info("Parking Request Received: " + obj);
			ParkingRequest request = GsonParkingRequest.fromJsonString((String) obj);
			logger.info("   Converted to command: " + request.toString());
			result = performCommand(request);
		} else if (obj instanceof GsonParkingRequest) {
			ParkingRequest request = ((GsonParkingRequest) obj).getParkingRequest();
			logger.info("GsonParkingRequest object received: " + request.toString());
			result = performCommand(request);
		} else {
			logger.info("Received Unexpected Type: " + obj.getClass().getName());
			result = new ParkingResponse(400, "Unexpected");
			result.addMessage("Unexpected Request Type " + obj.getClass().getName());
		}
		logger.info(" Returning Result " + result);
		logger.info("========End of Response========");
		return result;
	}

	public ParkingResponse performCommand(ParkingRequest command) {
		String[] args = command.getParameters();
		logger.log(Level.INFO, "Performing {0} command", command);
		ParkingResponse result = null;
		switch (command.getCommandName().toUpperCase()) {
		case "CUSTOMER":
			if (checkNumberOfParameters(2, args.length)) {
				Customer customer = new Customer();
				customer.setFirstName(checkName(args[0]));
				customer.setLastName(checkName(args[1]));
				parkingOffice.register(customer).toString();
				result = new ParkingResponse(200, "Success");
				result.addMessage("Action: Registered Customer");
				result.addMessage("CustomerID: " + customer.getCustomerId());
				System.out.println(result.toString());
			} else {
				result.addMessage("Cannot create customer: wrong number of parameters");
			}
			break;
		case "CAR":
			if (checkNumberOfParameters(2, args.length)) {
				Car car = new Car();
				car.setLicensePlate(checkLicensePlate(args[0]));
				car.setOwner(checkCustomer(args[1]));
				car.setType(CarType.SUV);
				parkingOffice.register(car);
				result = new ParkingResponse(200, "Success");
				result.addMessage("Action: Registered Car");
				System.out.println(result.toString());
			} else {
				result.addMessage("Cannot create car permit: wrong number of parameters");
			}
			break;
		case "PARK":
			if (checkNumberOfParameters(3, args.length)) {
				LocalDateTime dateTime = checkDateTime(args[2]);
				ParkingLot pl = checkParkingLot(args[0]);
				ParkingPermit parkedCar = checkParkingPermit(args[1]);
				ParkingTransaction transaction = parkingOffice.park(parkedCar, pl, dateTime, dateTime);
				if (transaction != null) {
					result = new ParkingResponse(200, "Success");
					result.addMessage("Action: Parked " + transaction.toString());
				} else {
					result.addMessage("Parking transaction failed. Parameters invalid");
				}
			} else {
				result.addMessage("Cannot park: wrong number of parameters");
			}
		case "STOP":
			ObjectWritingServer.stopServer();
			break;
		default:
			result = new ParkingResponse(400, "Unknown");
			result.addMessage("Request" + command + "not supported");
		}
		return result;
	}

	private static boolean checkNumberOfParameters(int expected, int provided) {
		boolean result = true;
		if (provided < expected) {
			logger.log(Level.SEVERE, "Not enough parameters! Expected {0} received {1}",
					new Object[] { expected, provided });
			result = false;
		}
		return result;
	}

	private static String checkName(String name) {
		String result = name;
		if (name == null) {
			result = "Unknown";
		}
		return result;
	}

	private static LocalDateTime checkDateTime(String dateTime) {
		LocalDateTime result = LocalDateTime.now();
		try {
			result = LocalDateTime.parse(dateTime);
		} catch (DateTimeParseException ex) {
			logger.log(Level.INFO, "Cannot parse datetime {0}: {1}", new Object[] { dateTime, ex });
		}
		return result;
	}

	private Customer checkCustomer(String customerId) {
		Customer customer = parkingOffice.getCustomer(customerId);
		if (customer == null) {
			customer = new Customer();
			customer.setFirstName("Unknown");
			parkingOffice.register(customer);
		}
		return customer;
	}

	private ParkingLot checkParkingLot(String lotId) {
		ParkingLot result = parkingOffice.getParkingLot(lotId);
		return result;
	}

	private static String checkLicensePlate(String plate) {
		String result = plate;
		if (result == null) {
			plate = "Unknown";
		}
		return result;
	}

	private ParkingPermit checkParkingPermit(String permitId) {
		ParkingPermit result;
		result = parkingOffice.getParkingPermit(permitId);
		return result;
	}

}