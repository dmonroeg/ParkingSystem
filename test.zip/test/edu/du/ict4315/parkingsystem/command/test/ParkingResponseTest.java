/////////////
//This is the ParkingResponseTest class
//File: ParkingResponseTest.java
// Author: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.command.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import edu.du.ict4315.parkingsystem.command.ParkingResponse;

public class ParkingResponseTest {

	ParkingResponse testResponse = new ParkingResponse(200, "Success");
	List<String> testMessages = new ArrayList<>();

	@Test
	public void testGetMessages() {
		testMessages.add("Action: Registered Customer");
		testMessages.add("Action: Registered Car");
		assertEquals(testMessages.toArray().length, testMessages.size());
	}

	@Test
	public void testGetResponseCode() {
		assertEquals(testResponse.getResponseCode(), 200);
	}

	@Test
	public void testGetResponseText() {
		assertEquals(testResponse.getResponseText(), "Success");
	}

	@Test
	public void testToString() {
		assertEquals(testResponse.toString(), "Response code: " + testResponse.getResponseCode() + ": ("
				+ testResponse.getResponseText() + ")::  " + testMessages.toString());
	}

}
