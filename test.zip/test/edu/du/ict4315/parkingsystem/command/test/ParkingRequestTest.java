/////////////
//This is the ParkingRequestTest class
//File: ParkingRequestTest.java
// Author: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.command.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import edu.du.ict4315.parkingsystem.command.ParkingRequest;

public class ParkingRequestTest {
	List<String> fieldName = new ArrayList<>();

	String[] customer = { "Daphne", "Monroe", "719-685-6408" };
	ParkingRequest testCustomerRequest = new ParkingRequest("CUSTOMER", customer, fieldName);

	String[] car = { "5678GHF", customer.toString() };
	ParkingRequest testCarRequest = new ParkingRequest("CAR", car, fieldName);

	@Test
	public void testGetCommandName() {
		assertEquals(testCustomerRequest.getCommandName(), "CUSTOMER");
	}

	@Test
	public void testGetCommandName2() {
		assertEquals(testCarRequest.getCommandName(), "CAR");
	}

	@Test
	public void testGetParameters() {
		assertArrayEquals(testCustomerRequest.getParameters(), customer);
	}

	@Test
	public void testGetParameters2() {
		assertArrayEquals(testCarRequest.getParameters(), car);
	}

	@Test
	public void testToString() {
		assertEquals(testCustomerRequest.toString(), "Command: " + testCustomerRequest.getCommandName() + "::  "
				+ String.join(", ", testCustomerRequest.getParameters()));
	}

	@Test
	public void testToString2() {
		assertEquals(testCarRequest.toString(), "Command: " + testCarRequest.getCommandName() + "::  "
				+ String.join(", ", testCarRequest.getParameters()));
	}

}
