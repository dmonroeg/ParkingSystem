/////////////
// This is the ObjectClientTest class
// File: ObjectClientTest.java
// Author: M I Schwartz
// Editor: Daphne M Goujon
////////////

package edu.du.ict4315.parkingsystem.clients.test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import edu.du.ict4315.parkingsystem.command.GsonParkingRequest;
import edu.du.ict4315.parkingsystem.command.GsonParkingResponse;
import edu.du.ict4315.parkingsystem.command.ParkingRequest;
import edu.du.ict4315.parkingsystem.command.ParkingResponse;

class ObjectClientTest {

	// This test assumes the server is up and running for now.
	// It does not start its own.
	private static final int PORT = 7777;
	private static final String SERVER = "localhost";

	public static ParkingResponse runCommand(ParkingRequest parkingRequest) throws IOException, ClassNotFoundException {

		InetAddress host = InetAddress.getByName(SERVER);
		ParkingResponse response = null;
		try (Socket link = new Socket(host, PORT);
				ObjectOutputStream osw = new ObjectOutputStream(link.getOutputStream());
				ObjectInputStream isw = new ObjectInputStream(link.getInputStream());) {
			System.out.println("You are now connected to: " + host.getHostAddress());

			Object o = new GsonParkingRequest(parkingRequest).getJsonObject();
			System.out.println(" Sending a " + o.getClass().getName());
			osw.writeObject(o);

			Object obj = isw.readObject();
			if (obj instanceof String) {
				response = GsonParkingResponse.fromJsonString(obj.toString());
				System.out.println(" Receiving a " + response);
			} else if (obj instanceof ParkingResponse) {
				response = (ParkingResponse) obj;
				System.out.println(response);
			} else {
				// remaining null
				// string already printed
			}
		}
		return response;
	}

	@Test
	final void testDemo() throws ClassNotFoundException, IOException {
		String[] parameters = new String[0];
		List<String> fieldNames = new ArrayList<String>();
		ParkingRequest[] requests = { new ParkingRequest("CUSTOMER", parameters, fieldNames),
				new ParkingRequest("CAR", parameters, fieldNames),
				new ParkingRequest("STOP", parameters, fieldNames), };
		ParkingResponse response;
		response = runCommand(requests[0]);
		assertEquals(response.getResponseCode(), 200);
		int total = 0;
		while (total < 17) {
			response = runCommand(requests[2]);
			assertEquals(response.getResponseCode(), 200);
			response = runCommand(requests[1]);
			assertEquals(response.getResponseCode(), 200);
			total = Integer.valueOf(response.getMessages()[0]);
		}
		response = runCommand(requests[3]);
		assertEquals(response.getResponseCode(), 200);
		assertTrue(total < 27);
		System.out.println(response);
	}

}
