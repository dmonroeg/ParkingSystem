/////////////
//This is the ParkingLotTest class
//File: ParkingLotTest.java
// Author: M I Schwartz
// Editor: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.parking.test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.du.ict4315.currency.Money;
import edu.du.ict4315.parkingsystem.parking.Address;
import edu.du.ict4315.parkingsystem.parking.Car;
import edu.du.ict4315.parkingsystem.parking.CarType;
import edu.du.ict4315.parkingsystem.parking.Customer;
import edu.du.ict4315.parkingsystem.parking.ParkingLot;
import edu.du.ict4315.parkingsystem.parking.ParkingOffice;
import edu.du.ict4315.parkingsystem.parking.ParkingPermit;

class ParkingLotTest {

	private ParkingOffice office;
	private ParkingLot lot;
	private List<String> permitIds = new ArrayList<>();
	private List<String> customerIds = new ArrayList<>();

	// create addresses, cars, & customers
	private final String[] streets = { "S. High St", "E. Main St.", "Front St.", "Second St.", "W. Main St." };
	private final String[] cities = { "Denver", "Boulder", "Glendale", "Aurora", "Longmont" };
	private final Random random = new Random();
	private final String[] firstNames = { "Chris", "JJ", "Stefanie", "Sharon" };
	private final String[] lastNames = { "Goujon", "Monroe", "Woodard", "Norred" };

	private Address createAddress() {
		Address address;
		String st = String.valueOf(random.nextInt(1000) + 1) + " " + streets[random.nextInt(streets.length)];
		String city = cities[random.nextInt(cities.length)];
		String zip = String.valueOf(80000 + random.nextInt(200));
		address = new Address.Builder().withStreetAddress1(st).withCity(city).withState("CO").withZip(zip).build();
		return address;
	}

	private Customer createCustomer(Address address) {
		Customer customer = new Customer();
		String firstName = firstNames[random.nextInt(firstNames.length)];
		String lastName = lastNames[random.nextInt(lastNames.length)];
		String phoneNumber = String.format("303-%3d-%04d", random.nextInt(900) + 100, random.nextInt(10000));
		customer = new Customer.Builder(firstName, lastName).withAddress(createAddress()).withPhoneNumber(phoneNumber)
				.build();
		return customer;
	}

	private Car createCar(Customer owner) {
		Car car = new Car();
		car.setOwner(owner);
		car.setType(CarType.values()[random.nextInt(CarType.values().length)]);
		car.setLicensePlate(String.format("XYZ-%03d", random.nextInt(1000)));
		return car;
	}
	// end of utility functions

	@BeforeEach
	void setUp() throws Exception {
		office = new ParkingOffice();
		// set address & name
		office.setParkingOfficeName("DU Parking Office -- Test");
		Address address;
		address = new Address.Builder().withStreetAddress1("2130 S. High St.").withCity("Denver").withState("CO")
				.withZip("80210").build();
		office.setParkingOfficeAddress(address);

		lot = office.getParkingLot("Lot 20");
		// Lot 20, Stadium View, 100 Players Way Denver CO 80210, $8

		Address add1 = createAddress();
		Customer c1 = createCustomer(add1);
		String id1 = office.register(c1);
		customerIds.add(c1.getCustomerId());
		assertEquals(id1, c1.getCustomerId());

		Address add2 = createAddress();
		Customer c2 = createCustomer(add2);
		String id2 = office.register(c2);
		customerIds.add(c2.getCustomerId());
		assertEquals(id2, c2.getCustomerId());

		// set up some cars, associate them with customer c1
		Car car1 = createCar(c1);
		Car car2 = createCar(c1);
		String car1Id = office.register(car1);
		String carId2 = office.register(car2);
		assertEquals(car1.getOwner(), c1);
		assertEquals(car2.getOwner(), c1);
		permitIds.add(car1Id);
		permitIds.add(carId2);
	}

	private String[] getPermitsWithCustomers(int howMany) {
		String[] result = new String[howMany];
		Collections.shuffle(permitIds);
		int j = 0;
		for (int i = 0; i < permitIds.size(); i++) {
			ParkingPermit tmp = office.getParkingPermit(permitIds.get(i));
			if (tmp != null && tmp.getCar() != null && tmp.getCar().getOwner() != null) {
				result[j++] = permitIds.get(i);
				if (j >= howMany) {
					break;
				}
			}
		}
		return result;
	}

	@Test
	void testToString() {
		System.out.println("\nPARKING LOT TEST CLASS:\n" + lot.toString());
		String expected = "Parking Lot: Lot 20" + "\nStadium View" + "\n" + lot.getAddress();
		String actual = office.getParkingLot("Lot 20").toString();
		assertEquals(expected, actual);
	}

	@Test
	void testGetWeekendParkingCharges() {
		System.out.println("Weekend Parking Charges: ");
		String[] permits = getPermitsWithCustomers(2);
		String permitId1 = permits[0];
		String permitId2 = permits[1];

		if (permitId1 == null || permitId2 == null) {
			System.err.println("Problem: no useful permits present");
			fail("no vail permits");
		}
		// 2 hour weekend charge
		LocalDateTime weekend = LocalDateTime.of(2022, 5, 8, 10, 15);
		weekend = weekend.minusHours(-1);
		lot.enterLot(weekend, permitId1);
		lot.enterLot(weekend, permitId2);
		Duration weekendDuration = Duration.between(weekend, weekend);

		ParkingPermit permit = office.getParkingPermit(permitId1);
		ParkingPermit permit2 = office.getParkingPermit(permitId2);
		Money mp1 = office.getParkingLot(lot.getId()).getParkingCharges(permit, weekend, weekendDuration);
		Money mp2 = office.getParkingLot(lot.getId()).getParkingCharges(permit2, weekend, weekendDuration);
		System.out.println("Permit: " + permit + "; Amount: " + mp1);
		assertEquals(mp1, lot.getParkingCharges(permit, weekend, weekendDuration));
		System.out.println("Permit: " + permit2 + "; Amount: " + mp2);
		assertEquals(mp2, lot.getParkingCharges(permit2, weekend, weekendDuration));
	}

	@Test
	void testGetWeekdayParkingCharges() {
		System.out.println("Weekday Parking Charges: ");
		String[] permits = getPermitsWithCustomers(2);
		String permitId1 = permits[0];
		String permitId2 = permits[1];

		if (permitId1 == null || permitId2 == null) {
			System.err.println("Problem: no useful permits present");
			fail("no vail permits");
		}

		// 3 hour weekday charge
		LocalDateTime weekday = LocalDateTime.of(2022, 6, 1, 12, 30);
		weekday = weekday.minusHours(-3);
		Duration weekdayDuration = Duration.between(weekday, weekday);
		lot.enterLot(weekday, permitId1);
		lot.enterLot(weekday, permitId2);

		ParkingPermit permit = office.getParkingPermit(permitId1);
		ParkingPermit permit2 = office.getParkingPermit(permitId2);
		Money mp1 = office.getParkingLot(lot.getId()).getParkingCharges(permit, weekday, weekdayDuration);
		Money mp2 = office.getParkingLot(lot.getId()).getParkingCharges(permit2, weekday, weekdayDuration);
		System.out.println("Permit: " + permit + "; Amount: " + mp1);
		assertEquals(mp1, lot.getParkingCharges(permit, weekday, weekdayDuration));
		System.out.println("Permit: " + permit2 + "; Amount: " + mp2);
		assertEquals(mp2, lot.getParkingCharges(permit2, weekday, weekdayDuration));
	}

}
