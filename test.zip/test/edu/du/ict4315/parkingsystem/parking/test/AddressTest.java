/////////////
//This is the AddressTest class
//File: AddressTest.java
//Author: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.parking.test;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.du.ict4315.parkingsystem.parking.Address;

public class AddressTest {

	Address testAddr = new Address.Builder().withStreetAddress1("1931 S 80th Dr").withCity("Phoenix").withState("AZ")
			.withZip("85043").build();

	@Test
	public void testGetAddressInfo() {
		System.out.println("\nADDRESS TEST CLASS\n");

		String expected = "1931 S 80th Dr" + "\nPhoenix, AZ" + "\n85043" + "\n";
		String actual = testAddr.getAddressInfo();
		assertEquals(expected, actual);
	}

}