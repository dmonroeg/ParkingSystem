/////////////
//This is the FileLoaderTest class
//File: FileLoaderTest.java
// Author: M I Schwartz
// Editor: Daphne M Goujon
////////////
package edu.du.ict4315.parkingsystem.support.test;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.du.ict4315.currency.Money;
import edu.du.ict4315.parkingsystem.parking.Address;
import edu.du.ict4315.parkingsystem.parking.ParkingLot;
import edu.du.ict4315.parkingsystem.parking.ParkingOffice;

public class FileLoaderTest {

	// Test data based on the data in the load files
	private final String[] lotIds = { "Lot 40", "Lot 30", "Lot 20", "Lot 50" };
	private final String[][] lotNames = { { "Lot 40", "Science East" }, { "Lot 30", "Arts North" },
			{ "Lot 20", "Stadium View" }, { "Lot 50", "Central" } };
	private final Money[] lotBaseRates = { Money.of(5.00), Money.of(2.00), Money.of(8.00), Money.of(8.00) };

	private final String[][] addresses = { { "Lot 40", "4040 Park Pl", "", "Denver", "CO", "80210" },
			{ "Lot 30", "40 Painter Ave", "", "Denver", "CO", "80210" },
			{ "Lot 20", "100 Players Way", "", "Denver", "CO", "80210" },
			{ "Lot 50", "3121 Campus Dr", "", "Denver", "CO", "80210" }, };

	private void checkName(ParkingOffice office) {
		for (String[] lotName : lotNames) {
			ParkingLot lot = office.getParkingLot(lotName[0]);
			assertTrue(lot.getName().contentEquals(lotName[1]));
		}
	}

	private void checkAddress(ParkingOffice office) {
		for (String[] address : addresses) {
			ParkingLot lot = office.getParkingLot(address[0]);
			Address a = lot.getAddress();
			assertTrue(a.getCity().equals(address[3]));
			assertTrue(a.getState().equals(address[4]));
			assertTrue(a.getZip().equals(address[5]));
			assertTrue(a.getStreetAddress1().equals(address[1]));
			assertTrue(a.getStreetAddress2().equals(address[2]));
		}
	}

	private void checkBaseRate(ParkingOffice office) {
		for (int i = 0; i < lotIds.length; i++) {
			ParkingLot lot = office.getParkingLot(lotIds[i]);
			assertTrue(lot.getBaseRate().equals(lotBaseRates[i]));
		}
	}

	private void checkParkingLotInitialization(ParkingOffice office) {
		// Check names
		checkName(office);

		// Check addresses
		checkAddress(office);

		// Check base rates
		checkBaseRate(office);

	}

	@Test
	final public void testInitialization() {
		ParkingOffice office = new ParkingOffice();
		checkParkingLotInitialization(office);
	}

}